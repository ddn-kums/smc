#!/bin/bash

# ALL 30 x LUX client nodes
#CLIENT_NODES="lux01-ib0 lux02-ib0 lux03-ib0 lux05-ib0 lux07-ib0 lux08-ib0 lux09-ib0 lux10-ib0 lux11-ib0 lux12-ib0 lux13-ib0 lux14-ib0 lux17-ib0 lux18-ib0 lux19-ib0 lux20-ib0 lux21-ib0 lux22-ib0 lux23-ib0 lux24-ib0 lux25-ib0 lux28-ib0 lux29-ib0 lux30-ib0 lux31-ib0 lux32-ib0 lux35-ib0 lux36-ib0 lux37-ib0 lux38-ib0"
# Switch#1  LUX client nodes
#CLIENT_NODES="lux01-ib0 lux02-ib0 lux03-ib0 lux05-ib0 lux07-ib0 lux08-ib0 lux09-ib0 lux10-ib0 lux11-ib0 lux12-ib0 lux13-ib0 lux14-ib0"
# Switch#2  LUX client nodes
#CLIENT_NODES="lux17-ib0 lux18-ib0 lux19-ib0 lux20-ib0 lux21-ib0 lux22-ib0 lux23-ib0 lux24-ib0 lux25-ib0 lux28-ib0"
# Switch#3  LUX client nodes
#CLIENT_NODES="lux29-ib0 lux30-ib0 lux31-ib0 lux32-ib0 lux35-ib0 lux36-ib0 lux37-ib0 lux38-ib0"
# Subset of  LUX client nodes
#CLIENT_NODES="lux01-ib0 lux02-ib0"
# Subset of Infinia server nodes as clients
#CLIENT_NODES="red02-ext-ib0 red03-ext-ib0 red04-ext-ib0 red05-ext-ib0 red06-ext-ib0 red07-ext-ib0 red08-ext-ib0 red09-ext-ib0 red10-ext-ib0 red11-ext-ib0 red12-ext-ib0"
CLIENT_NODES="red03-ext-ib0 red06-ext-ib0"
#CLIENT_COUNT=30
#CLIENT_COUNT=12
#CLIENT_COUNT=10
#CLIENT_COUNT=8
CLIENT_COUNT=2
#Server Node
SERVER_NODES="red01-ext-ib0"
#SERVER_NODES="red10-ext-ib0"
SRVR_COUNT=1
#TIME=60
TIME=60
S_TIME=10
MIN_BUFFSIZE=2097152
MAX_BUFFSIZE=4194304
THREADS=32
SLEEPT=3
MODE="final"
#MODE="quick"

#nsdperf binary
#NSDPERFC="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r  mlx5_0/1"
NSDPERFC="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r ibp193s0f1/1"
NSDPERFS="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r ibp193s0f1/1"
NSDPERFL="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r ibp193s0f1/1"

#nsdperf infile
IF="/home/krajara/benchmarks/nsdperf/scripts/nsdperf_RDMA_HSE.in"


# NSDPERF IB TEST
OF="/home/krajara/benchmarks/nsdperf/results/$MODE/nsdperf_RDMA_C${CLIENT_COUNT}_S${SRVR_COUNT}.`date +%F-%T`.txt"
echo "nsdperf server mode started" | tee -a $OF

for (( io_sz=$MIN_BUFFSIZE; io_sz <= $MAX_BUFFSIZE; io_sz *= 2)) 
do
   #Populate infile
   echo client $CLIENT_NODES > $IF
   echo server $SERVER_NODES >> $IF
   echo buffsize $io_sz >> $IF
   echo threads $THREADS >> $IF
   echo ttime $TIME >> $IF
   echo rdma all >> $IF
   echo status >> $IF
   echo test >> $IF
   echo quit >> $IF

   echo "Starting nsdperf RDMA test on: `date`" | tee -a $OF
   echo "nsdperf test parameters -  BUFFSIZE: $io_sz" | tee -a $OF
   $NSDPERFL -i $IF 2>&1 | tee -a $OF
   sleep $SLEEPT
done
 
echo "nsdperf RDMA Bandwidth Perf test completed: `date`"  |tee -a $OF

echo "Performing nsdperf test  and Terminating nsdperf server connections"
#Populate infile
echo client $CLIENT_NODES > $IF
echo server $SERVER_NODES >> $IF
echo buffsize $MAX_BUFFSIZE >> $IF
echo ttime $S_TIME >> $IF
echo threads $THREADS >> $IF
echo rdma all >> $IF
echo status >> $IF
echo test >> $IF
echo killall >> $IF
echo quit >> $IF

OF="/home/krajara/benchmarks/nsdperf/results/tmp/nsdperf_RDMA_TEST_C${CLIENT_COUNT}_S${SRVR_COUNT}.`date +%F-%T`.txt"
$NSDPERFL -i $IF 2>&1 | tee -a $OF
sleep $SLEEPT
