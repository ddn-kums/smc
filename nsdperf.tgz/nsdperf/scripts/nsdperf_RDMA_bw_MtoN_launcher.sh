#!/bin/bash

echo "Launching the nsdperf RDMA server"

# ALL 30 x LUX client nodes
#CLIENT_NODES="lux01,lux02,lux03,lux05,lux07,lux08,lux09,lux10,lux11,lux12,lux13,lux14,lux17,lux18,lux19,lux20,lux21,lux22,lux23,lux24,lux25,lux28,lux29,lux30,lux31,lux32,lux35,lux36,lux37,lux38"
# Switch#1 LUX client nodes
#CLIENT_NODES="lux01,lux02,lux03,lux05,lux07,lux08,lux09,lux10,lux11,lux12,lux13,lux14"
# Switch#2 LUX client nodes
#CLIENT_NODES="lux17,lux18,lux19,lux20,lux21,lux22,lux23,lux24,lux25,lux28"
# Switch#3 LUX client nodes
#CLIENT_NODES="lux29,lux30,lux31,lux32,lux35,lux36,lux37,lux38"
# Subset of  client nodes
#CLIENT_NODES="lux01,lux02"
# Infinia server nodes as client nodes
#CLIENT_NODES="red02,red03,red04,red05,red06,red07,red08,red09,red10,red11,red12"
#CLIENT_NODES="red03"
#Server Node
#SERVER_NODES="red01"
#SERVER_NODES="red10"
# Between lux nodes in Switch#1
SERVER_NODES="lux01"
# Switch#1 LUX client nodes
CLIENT_NODES="lux02,lux03,lux05,lux07,lux08,lux09,lux10,lux11,lux12,lux13,lux14"
#CLIENT_NODES="lux02"
SLEEPT=2

#nsdperf binary
NSDPERFC="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r  mlx5_0/1"
# ext-ib0
#NSDPERFC="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r ibp193s0f1/1"
# int-ib0
#NSDPERFC="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r ibp193s0f0/1"
# ext-ib0 
#NSDPERFS="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r ibp193s0f1/1"
# int-ib0
#NSDPERFS="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r ibp193s0f0/1"
# lux
NSDPERFS="/home/krajara/benchmarks/nsdperf/net/nsdperf-rdma -r  mlx5_0/1"

#NSDPerf Logs
LOG_DIR="/tmp/kums"
LOG_FILE="/tmp/kums/nsdperf.log"

echo "Launch the nsdperf on lux-login1 with pdsh access to the client and servers"

# NSDPERF IB TEST
# Launch nsdperf on the client nodes
echo "Launching nsdperf -s on the client nodes"
pdsh -w $CLIENT_NODES "mkdir -p $LOG_DIR"
sleep $SLEEPT
pdsh -w $CLIENT_NODES "$NSDPERFC -s </dev/null > $LOG_FILE 2>&1 &"
sleep $SLEEPT
echo "Verifying nsdperf -s on client nodes"
pdsh -w $CLIENT_NODES "pgrep nsdperf" | wc -l

# Launch nsdperf on the server nodes
echo "Launching nsdperf -s on the server nodes"
pdsh -w $SERVER_NODES "mkdir -p $LOG_DIR"
sleep $SLEEPT
pdsh -w $SERVER_NODES "$NSDPERFS -s </dev/null > $LOG_FILE 2>&1 &"
sleep $SLEEPT
echo "Verifying nsdperf -s on server nodes"
pdsh -w $SERVER_NODES "pgrep nsdperf" | wc -l
